const Reg=require('../models/reg')
const nodemailer=require('nodemailer')
const bcrypt=require('bcrypt')


exports.loginpage=(req,res)=>{
     res.render('login.ejs',{message:''})
}

exports.singuppage=(req,res)=>{
     res.render('singupform.ejs',{message:''})
}
exports.cerateaccount= async (req,res)=>{
     try{
     const {semail,pass}=req.body
    const usercheck=await Reg.findOne({email:semail})
    if(usercheck==null){     
    const hashpass=await bcrypt.hash(pass,10)
    const record=Reg({email:semail,password:hashpass})
    //console.log(hashpass)
     record.save()
     //console.log(record)
     const transporter = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 587,
          secure: false,
          auth: {
            // TODO: replace `user` and `pass` values from <https://forwardemail.net>
            user: "kumawatpravin4566@gmail.com",
            pass: "qqeuhvwxwqqprsgk",
          },
        });
        console.log('Connected to smtp gmail server')
        const info = await transporter.sendMail({
          from: 'kumawatpravin4566@gmail.com', // sender address
          to: semail, // list of receivers
          subject: 'Email Verification Mail From xyz.com', // Subject line
          //text: "", // plain text body
          html: `<a href=http://localhost:5000/emailverifiy/${record.id}>Click to verifiy</a>`, // html body
        });
      
     res.render('singupform.ejs',{message:'Successfuly account has been created please check your email to verifiy it.'})
     }else{
          res.render('singupform.ejs',{message:`${semail} Email is already registered with us`})
     }
}catch(error){
     console.log(error.message)
}
}

exports.emailverification= async (req,res)=>{
     try{
     const id=req.params.id
      await Reg.findByIdAndUpdate(id,{status:'Active'})
     res.render('verifiymessage.ejs')
     }catch(error){
          console.log(error.message)
     }
}
exports.logincheck= async (req,res)=>{
     try{
     const {lemail,pass}=req.body
     const logincheck= await Reg.findOne({email:lemail})
     if(logincheck!==null){
        const passcheck=await bcrypt.compare(pass,logincheck.password)
        //console.log(passcheck)
          if(passcheck){
          if(logincheck.status=='Active') 
                
          if(lemail!==process.env.ADMIN_EMAIL){
               req.session.username=logincheck.email
               req.session.userid=logincheck.id
               req.session.isAuth=true  
               req.session.role=logincheck.role  
          res.redirect('/blog/')
     }else{
          res.redirect('/admin/dashboard')
     }
     else{
          res.render('login.ejs',{message:"your's account is suspended. Please check your email to verifiy it."})
     }
     }else{
               res.render('login.ejs',{message:'Worng Credentails'})
     }
     }else{
          res.render('login.ejs',{message:'Worng Credentails'})
     }
}catch(error){
     console.log(error.message)
}
}
exports.forgotform=(req,res)=>{
     //console.log(req.params.id)
     res.render('forgotform.ejs',{message:''})
}
exports.forgotpasswordupdate= async (req,res)=>{
     try{
     const {npass,cpass}=req.body
     const id=req.params.id
    const newpass=await bcrypt.hash(npass,10)
    if(npass==cpass){
    await Reg.findByIdAndUpdate(id,{password:newpass})
    res.render('forgotchangmess.ejs')
    }else{
     res.render('forgotform.ejs',{message:'Password Not Matched'})
    }
}catch(error){
     console.log(error.message)
}
}
exports.femailform=(req,res)=>{
     res.render('femailform.ejs',{message:''})
}
exports.forgotlinksend= async (req,res)=>{
     try{
     const {semail}=req.body
    const emailvalidate=await Reg.findOne({email:semail})
    if(emailvalidate!==null){
     const transporter = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 587,
          secure: false,
          auth: {
            // TODO: replace `user` and `pass` values from <https://forwardemail.net>
            user: "kumawatpravin4566@gmail.com",
            pass: "qqeuhvwxwqqprsgk",
          },
        });
        console.log('Connected to smtp gmail server')
        const info = await transporter.sendMail({
          from: 'kumawatpravin4566@gmail.com', // sender address
          to: semail, // list of receivers
          subject: 'Change Password Link', // Subject line
          //text: "", // plain text body
          html: `<a href=http://localhost:5000/forgotform/${emailvalidate.id}>Click to verifiy</a>`, // html body
        });
        res.render('femailform.ejs',{message:'Check your registered email id for password change link'})
    }else{
     res.render('femailform.ejs',{message:'Email Not Found'})
    }
}catch(error){
     console.log(error.message)
}
}
exports.logout=(req,res)=>{
     req.session.destroy()
     res.redirect('/')
}
exports.profileupdateform=async (req,res)=>{
     try{
     const username=req.session.username
     const userdata=await Reg.findOne({email:username})
      res.render('profileupdateform.ejs',{username,userdata,message:''})
     }catch(error){
          console.log(error.message)
     }
}
exports.profileupdate= async (req,res)=>{
     try{
     const username=req.session.username
      const id= req.session.userid      
      const {fname,lname,mob,gender,desc}=req.body
      if(req.file){
          const filename=req.file.filename
          await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mob,gender,desc:desc,image:filename})
      }else{
          await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mob,gender,desc:desc})
      }    
      res.redirect('/profileupdate')
     }catch(error){
          console.log(error.message)
     }
}
