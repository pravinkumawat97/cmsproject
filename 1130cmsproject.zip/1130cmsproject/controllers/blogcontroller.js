const Blog=require('../models/blog')

exports.allblogs= async (req,res)=>{   
    const username=req.session.username
    const allblog=await  Blog.find().sort({postedDate:-1})
    res.render('blogs.ejs',{username,allblog})   
}
exports.userblogs=async (req,res)=>{    
    const username=req.session.username
     let message=req.params.message
    const allblog=await Blog.find({username:username}).sort({postedDate:-1})    
     res.render('userblog.ejs',{username,allblog,message})    
}
exports.addblogform=(req,res)=>{ 
    const username=req.session.username
    res.render('addform.ejs',{username,message:''})    
}
exports.blogadd=(req,res)=>{
    try{    
    const username=req.session.username
     const {title,desc,mdetail}=req.body
     if(req.file){
        const filename=req.file.filename
     var newblog= Blog({title:title,desc:desc,moreDetails:mdetail,username:username,image:filename})        
     }else{
        var newblog= Blog({title:title,desc:desc,moreDetails:mdetail,username:username})        
     } 
     newblog.save()    
        res.render('addform.ejs',{username,message:'Successfully blog has been added'}) 
    }catch(error){
        console.log(error.message)
    }  
}
exports.blogupdateform= async (req,res)=>{
    const username=req.session.username
    const id=req.params.id
     const record=await Blog.findById(id)
     res.render('blogupdateform.ejs',{username,record})
}
exports.blogupdate= async (req,res)=>{   
     const id=req.params.id
     let message='Successfully blog has been update'
     const {title,desc,mdetail}=req.body    
    if(req.file){        
        const filename=req.file.filename
        await Blog.findByIdAndUpdate(id,{title:title,desc:desc,moreDetails:mdetail,image:filename})
    }else{
        await Blog.findByIdAndUpdate(id,{title:title,desc:desc,moreDetails:mdetail})
    }
     res.redirect(`/blog/userblog/${message}`)
}
exports.blogdelete= async (req,res)=>{
    const id=req.params.id
    let message='Successfully blog deleted'
   await Blog.findByIdAndDelete(id)
   res.redirect(`/blog/userblog/${message}`)
}
exports.blogmoredetails= async (req,res)=>{
    const id=req.params.id
    const username=req.session.username
   const record=await Blog.findById(id)
    res.render('moredetails.ejs',{username,record})
}