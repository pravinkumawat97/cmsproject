const router=require('express').Router()
const upload=require('../helpers/multer')
const regc=require('../controllers/regcontroller')

router.get('/dashboard',(req,res)=>{
    res.send('welcom to admin router')
})


module.exports=router