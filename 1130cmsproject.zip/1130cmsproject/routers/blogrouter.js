const router=require('express').Router()
const blogc=require('../controllers/blogcontroller')
const handlelogin=require('../helpers/handlelogin')
const upload=require('../helpers/multer')
const handlesub=require('../helpers/subscription')

//all blogs
router.get('/',handlelogin,handlesub,blogc.allblogs)
//user blogs
router.get('/userblog/:message',handlelogin,blogc.userblogs)
//create blogs
router.get('/create',handlelogin,blogc.addblogform)
router.post('/create',upload.single('img'),blogc.blogadd)
//update blogs
router.get('/blogupdate/:id',handlelogin,blogc.blogupdateform)
router.post('/blogupdate/:id',upload.single('img'),blogc.blogupdate)
//delete blogs
router.get('/blogdelete/:id',handlelogin,blogc.blogdelete)
//more details
router.get('/moredetails/:id',handlelogin,blogc.blogmoredetails)

module.exports=router