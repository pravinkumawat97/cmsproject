 function handlesub(req,res,next){
    if(req.session.role!=='Public'){
        next()
    }else{
         res.render('suberror.ejs')
    }     
 }

 module.exports=handlesub