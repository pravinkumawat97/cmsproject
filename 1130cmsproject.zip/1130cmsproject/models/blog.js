const mongoose=require('mongoose')

const blogSchema=mongoose.Schema({
    title:{type:String,require:true},
    desc:{type:String,require:true},
    moreDetails:{type:String,require:true},
    image:{type:String,default:'avatar.jpg'},
    postedDate:{type:Date,default:new Date()},
    username:{type:String,require:true}
})

module.exports=mongoose.model('blog',blogSchema)