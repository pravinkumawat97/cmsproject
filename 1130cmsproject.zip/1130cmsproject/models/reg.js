const mongoose=require('mongoose')

const regSchema=mongoose.Schema({
       email:{type:String,require:true},
       password:{type:String,require:true},
       firstName:String,
       lastName:String,
       mobile:Number,
       gender:String,
       desc:String,       
       image:String,
       role:{type:String,default:'public'},
       status:{type:String,default:'Suspended'},
       postedDate:{type:Date,default:new Date()}

 })

 module.exports=mongoose.model('reg',regSchema)
